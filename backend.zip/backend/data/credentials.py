# Rename this file to credentials.py (NOT credentials.py.example)
# Credentials for SQLAlchemy, change 'db-url' to actual database URL login

# Schema: "postgres+psycopg2://<USERNAME>:<PASSWORD>@<IP_ADDRESS>:<PORT>/<DATABASE_NAME>"
db_login = 'postgresql+psycopg2://matt594:UACk3sfFZ337@bookrus.ccpec27yf35b.us-west-2.rds.amazonaws.com:5432/postgres'